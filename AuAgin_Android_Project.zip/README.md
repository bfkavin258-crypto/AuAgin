# AuAgin Android project

Native Android starter app using Kotlin and Jetpack Compose.

## Included
- AuAgin dashboard
- Gold 24K and silver 999 cards
- All India / city selector
- Refresh control and last-updated status
- HTTPS API integration scaffold

## Live pricing setup
Live market data is not connected yet. The app deliberately shows `₹ --` rather than invented prices.

Choose a price-data provider that permits display in your app, then create an HTTPS backend. Keep the provider's secret key on the backend, not in the Android app.

The app expects `GET /prices?region=india` to return:
```json
{
  "updatedAt": "2026-11-04 09:00 IST",
  "gold24k": {"perGram": 12345.67, "changePercent": 0.42},
  "silver": {"perGram": 150.25, "changePercent": -0.18}
}
```
Set `apiBaseUrl` in `MainActivity.kt` to your backend URL. Extend the backend for city-wise rates and show provider attribution in the production app.

## Open and run
Open this folder in Android Studio, allow Gradle sync, connect an Android phone or emulator, and press Run.

This ZIP contains source code, not a ready-to-install APK.
