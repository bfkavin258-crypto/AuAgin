package com.auagin.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale

private val navy = Color(0xFF101827)
private val panel = Color(0xFF1B293B)
private val gold = Color(0xFFF2C45C)
private val muted = Color(0xFF9AA9BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AuAginScreen() }
    }
}

data class Rate(val perGram: Double, val change: Double?)

@Composable
fun AuAginScreen() {
    var region by remember { mutableStateOf("All India") }
    var goldRate by remember { mutableStateOf<Rate?>(null) }
    var silverRate by remember { mutableStateOf<Rate?>(null) }
    var updated by remember { mutableStateOf("Not updated") }
    var message by remember { mutableStateOf("Connect a licensed price-data provider to show live rates.") }
    var busy by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Add your HTTPS backend URL here. Keep provider API keys on the backend, never in the app.
    val apiBaseUrl = ""

    suspend fun refresh() {
        if (apiBaseUrl.isBlank()) {
            message = "Live data is not connected yet. No sample prices are displayed."
            return
        }
        busy = true
        try {
            val data = withContext(Dispatchers.IO) {
                val req = Request.Builder().url("$apiBaseUrl/prices?region=india").build()
                OkHttpClient().newCall(req).execute().use { res ->
                    check(res.isSuccessful) { "HTTP ${res.code}" }
                    JSONObject(res.body?.string() ?: error("Empty response"))
                }
            }
            val g = data.getJSONObject("gold24k")
            val s = data.getJSONObject("silver")
            goldRate = Rate(g.getDouble("perGram"), g.optDouble("changePercent"))
            silverRate = Rate(s.getDouble("perGram"), s.optDouble("changePercent"))
            updated = data.optString("updatedAt", "Recently")
            message = "Prices loaded from configured provider."
        } catch (_: Exception) {
            message = "Could not update prices. Check connection and data provider."
        } finally { busy = false }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = gold, background = navy, surface = panel)) {
        Column(
            Modifier.fillMaxSize().background(navy).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("AuAgin", color = gold, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("GOLD  •  SILVER  •  INDIA", color = muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                }
                Text("DAILY RATES", color = Color.White, modifier = Modifier.background(panel, RoundedCornerShape(24.dp)).padding(12.dp), fontSize = 11.sp)
            }
            Text("Market overview", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Box {
                OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(region, modifier = Modifier.weight(1f))
                    Text("⌄")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf("All India", "Chennai", "Mumbai", "Delhi", "Kolkata", "Bengaluru", "Hyderabad").forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { region = it; menu = false })
                    }
                }
            }
            RateCard("GOLD 24K", "Price per gram", goldRate, gold)
            RateCard("SILVER 999", "Price per gram", silverRate, Color(0xFFD9E1EA))
            Button(onClick = { scope.launch { refresh() } }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (busy) "Updating…" else "Refresh prices")
            }
            LaunchedEffect(Unit) { refresh() }
            Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Last updated: $updated", color = gold, fontWeight = FontWeight.SemiBold)
                Text(message, color = muted, fontSize = 12.sp)
            }
            Text("Rates vary by city, purity, taxes and jeweller. Verify the final retail price. AuAgin is an information tracker, not an investment service.", color = muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun RateCard(title: String, subtitle: String, rate: Rate?, accent: Color) {
    Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(20.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(title, color = accent, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text(subtitle, color = muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = accent)
        }
        Text(rate?.let { "₹" + String.format(Locale("en", "IN"), "%,.2f", it.perGram) } ?: "₹ --", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("PER GRAM" + (rate?.change?.let { "   ${if (it >= 0) "+" else ""}${"%.2f".format(it)}%" } ?: ""), color = muted, fontSize = 11.sp)
    }
}
